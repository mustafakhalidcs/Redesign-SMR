# fancy-alert-and-confirm-angularjs
fancy-alert-and-confirm-angularjs
